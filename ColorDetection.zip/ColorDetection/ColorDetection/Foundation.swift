//
//  Foundation.swift
//  ColorDetection
//
//  Created by ykwon on 5/16/18.
//  Copyright © 2018 BarbarianGroup. All rights reserved.
//

import Foundation

typealias DictionarySA = Dictionary<String, AnyObject>

let POKEMON_TYPES_JSON_PATH = Bundle.main.path(forResource: "Products", ofType: "json")
