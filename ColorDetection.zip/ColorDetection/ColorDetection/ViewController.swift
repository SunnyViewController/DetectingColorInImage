//
//  ViewController.swift
//  ColorDetection
//
//  Created by ykwon on 5/15/18.
//  Copyright © 2018 BarbarianGroup. All rights reserved.
//

import UIKit
import GLKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var colorLabel: UILabel!
    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var similarcolorView: UIView!
    @IBOutlet var paletteLabels: [UILabel]!
    @IBOutlet var paletteViews: [UIView]!
    @IBOutlet var similarpaletteViews: [UIView]!
    
    var essieColors: [EssieColor] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadInitialData()
        print("Essiecolors : " + "\(self.essieColors.count)")
    }
    
    func parseJSON(contentsOfFile path: String?) -> [DictionarySA] {
        do {
            if let path = path, let data = NSData(contentsOfFile: path) as? Data {
                if let jsonData = try JSONSerialization.jsonObject(with: data, options: []) as? [DictionarySA] {
                    
                    return jsonData
                }
            }
        } catch {
            print("Fail Parsing JSON \(error)")
        }
        return [DictionarySA]()
    }
    
    func loadInitialData() {
        let typeJSON = parseJSON(contentsOfFile: POKEMON_TYPES_JSON_PATH)
        
        for json in typeJSON {
            if let _id = json["_id"] as? String,
            let productName = json["productName"] as? String,
            let productCategory = json["productCategory"] as? String,
            let productSubCategory = json["productSubCategory"] as? String,
            let hexValue = json["hexValue"] as? String,
            let shortDescription = json["shortDescription"] as? String,
            let longDescription = json["longDescription"] as? String,
            let finish = json["finish"] as? String,
            let productCollection = json["productCollection"] as? String,
            let productImage = json["productImage"] as? String,
            let productSwatch = json["productSwatch"] as? String,
            let collectionCategory = json["collectionCategory"] as? String {
                essieColors.append(EssieColor(_id: _id, productName: productName, productCategory: productCategory, productSubCategory: productSubCategory, hexValue: hexValue, shortDescription: shortDescription, longDescription: longDescription, finish: finish, productCollection: productCollection, productImage: productImage, productSwatch: productSwatch, collectionCategory: collectionCategory))
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonTapped(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else { return }
        imageView.image = image
        
        DispatchQueue.global(qos: .default).async {
            guard let colors = ColorThief.getPalette(from: image, colorCount: 10, quality: 1, ignoreWhite: true) else {
                return
            }
            let start = Date()
            guard let dominantColor = ColorThief.getColor(from: image) else {
                return
            }
            let elapsed = -start.timeIntervalSinceNow
            NSLog("time for getColorFromImage: \(Int(elapsed * 1000.0))ms")
            DispatchQueue.main.async { [weak self] in
                for i in 0 ..< 9 {
                    if i < colors.count {
                        let color = colors[i]
                        self?.paletteViews[i].backgroundColor = color.makeUIColor()
                        let redText = UInt8(color.r)
                        let greenText = UInt8(color.g)
                        let blueText = UInt8(color.b)
                        let redString = String(format: "%2X", redText)
                        let greenString = String(format: "%2X", greenText)
                        let blueString = String(format: "%2X", blueText)
                        //"[\(i)] #\(redString)\(greenString)\(blueString)"
                        let hexColor = "\(redString)\(greenString)\(blueString)"
                        var essieColorName = hexColor
                        var essieI = 0
                        var essieColorArray: [EssieColor] = []
                        while essieI < (self?.essieColors.count)! {
                            let item = self?.essieColors[essieI]
                            essieI += 1
                            if item?.hexValue == hexColor {
                                essieColorArray.append(item!)
                            }
                        }
                        if essieColorArray.count != 0 {
                            essieColorName = "[\(i)] #\(hexColor) -> \(essieColorArray[0].productName)"
                        } else {
                            let essie1hex = (self?.essieColors[0].hexValue)!
                            var rgbHexInt: UInt64 = 0
                            let scanner = Scanner(string: essie1hex)
                            scanner.scanLocation = 0
                            scanner.scanHexInt64(&rgbHexInt)
                            let essie1red = CGFloat((rgbHexInt & 0xff0000) >> 16) / 0xff * 100
                            let essie1green = CGFloat((rgbHexInt & 0xff00) >> 8) / 0xff * 100
                            let essie1blue = CGFloat(rgbHexInt & 0xff) / 0xff * 100
                            
                            var standard = GLKVector3Distance(GLKVector3Make(Float(essie1red), Float(essie1green), Float(essie1blue)), GLKVector3Make(Float(color.r), Float(color.g), Float(color.b)))
                            
                            var essiefinalhex = essie1hex
                            var distanceI = 1
                            //(self?.essieColors.count)!
                            while distanceI < (self?.essieColors.count)! {
                                if (self?.essieColors[distanceI].hexValue)! == "MISSING" || (self?.essieColors[distanceI].hexValue)! == "8.01E+11" || (self?.essieColors[distanceI].hexValue)! == "NO HEX" || (self?.essieColors[distanceI].hexValue)! == "no hex" || (self?.essieColors[distanceI].hexValue)! == "8.66E+80" || (self?.essieColors[distanceI].hexValue)! == "" || (self?.essieColors[distanceI].hexValue)! == "6.21E+55" {
                                    
                                } else {
                                    let essiehex = (self?.essieColors[distanceI].hexValue)!
                                    var rgbHexInt: UInt64 = 0
                                    let scanner = Scanner(string: essiehex)
                                    scanner.scanLocation = 0
                                    scanner.scanHexInt64(&rgbHexInt)
                                    let essiered = CGFloat((rgbHexInt & 0xff0000) >> 16) / 0xff * 100
                                    let essiegreen = CGFloat((rgbHexInt & 0xff00) >> 8) / 0xff * 100
                                    let essieblue = CGFloat(rgbHexInt & 0xff) / 0xff * 100
                                    
                                    let distance = GLKVector3Distance(GLKVector3Make(Float(essiered), Float(essiegreen), Float(essieblue)), GLKVector3Make(Float(color.r), Float(color.g), Float(color.b)))
                                    if standard > distance {
                                        standard = distance
                                        essiefinalhex = essiehex
                                    }
                                }
                                
                                distanceI += 1
                            }
                            //print(finalessiered)
                            
                            essieColorName = "[\(i)] #\(hexColor) -> similar #\(essiefinalhex)"
                            self?.similarpaletteViews[i].backgroundColor = self?.colorRromRGB(colorCode: "\(essiefinalhex)")
                        }
                        
                        self?.paletteLabels[i].text = essieColorName
                        
                    } else {
                        self?.paletteViews[i].backgroundColor = UIColor.white
                        self?.paletteLabels[i].text = "-"
                    }
                }
                
                self?.colorView.backgroundColor = dominantColor.makeUIColor()
                let domainRedText = UInt8(dominantColor.r)
                let domainGreenText = UInt8(dominantColor.g)
                let domainBlueText = UInt8(dominantColor.b)
                let domainRedString = String(format: "%2X", domainRedText)
                let domainGreenString = String(format: "%2X", domainGreenText)
                let domainBlueString = String(format: "%2X", domainBlueText)
                //R\(dominantColor.r) G\(dominantColor.g) B\(dominantColor.b)
                
                let hexColor = "\(domainRedString)\(domainGreenString)\(domainBlueString)"
                var essieColorName = hexColor
                var essieI = 0
                var essieColorArray: [EssieColor] = []
                while essieI < (self?.essieColors.count)! {
                    let item = self?.essieColors[essieI]
                    essieI += 1
                    if item?.hexValue == hexColor {
                        essieColorArray.append(item!)
                    }
                }
                if essieColorArray.count != 0 {
                    essieColorName = "DomainColor #\(hexColor) -> \(essieColorArray[0].productName)"
                } else {
                    let essie1hex = (self?.essieColors[0].hexValue)!
                    var rgbHexInt: UInt64 = 0
                    let scanner = Scanner(string: essie1hex)
                    scanner.scanLocation = 0
                    scanner.scanHexInt64(&rgbHexInt)
                    let essie1red = CGFloat((rgbHexInt & 0xff0000) >> 16) / 0xff * 100
                    let essie1green = CGFloat((rgbHexInt & 0xff00) >> 8) / 0xff * 100
                    let essie1blue = CGFloat(rgbHexInt & 0xff) / 0xff * 100
                    
                    var standard = GLKVector3Distance(GLKVector3Make(Float(essie1red), Float(essie1green), Float(essie1blue)), GLKVector3Make(Float(dominantColor.r), Float(dominantColor.g), Float(dominantColor.b)))
                    
                    var essiefinalhex = essie1hex
                    var distanceI = 1
                    //(self?.essieColors.count)!
                    while distanceI < (self?.essieColors.count)! {
                        if (self?.essieColors[distanceI].hexValue)! == "MISSING" || (self?.essieColors[distanceI].hexValue)! == "8.01E+11" || (self?.essieColors[distanceI].hexValue)! == "NO HEX" || (self?.essieColors[distanceI].hexValue)! == "no hex" || (self?.essieColors[distanceI].hexValue)! == "8.66E+80" || (self?.essieColors[distanceI].hexValue)! == "" || (self?.essieColors[distanceI].hexValue)! == "6.21E+55" {
                            
                        } else {
                            let essiehex = (self?.essieColors[distanceI].hexValue)!
                            var rgbHexInt: UInt64 = 0
                            let scanner = Scanner(string: essiehex)
                            scanner.scanLocation = 0
                            scanner.scanHexInt64(&rgbHexInt)
                            let essiered = CGFloat((rgbHexInt & 0xff0000) >> 16) / 0xff * 100
                            let essiegreen = CGFloat((rgbHexInt & 0xff00) >> 8) / 0xff * 100
                            let essieblue = CGFloat(rgbHexInt & 0xff) / 0xff * 100
                            
                            let distance = GLKVector3Distance(GLKVector3Make(Float(essiered), Float(essiegreen), Float(essieblue)), GLKVector3Make(Float(dominantColor.r), Float(dominantColor.g), Float(dominantColor.b)))
                            if standard > distance {
                                standard = distance
                                essiefinalhex = essiehex
                            }
                        }
                        
                        distanceI += 1
                    }
                    //print(finalessiered)
                    
                    essieColorName = "DomainColor #\(hexColor) -> similar #\(essiefinalhex)"
                    self?.similarcolorView.backgroundColor = self?.colorRromRGB(colorCode: "\(essiefinalhex)")
                }
                
                self?.colorLabel.text = essieColorName
            }
        }
    }
    
    func colorRromRGB(colorCode:String)->UIColor{
        var rgbVlaue:String = colorCode
        if rgbVlaue.lengthOfBytes(using: String.Encoding.utf8)<6 {
            return UIColor.white
        }
        if rgbVlaue.hasPrefix("0x") {
            rgbVlaue = (rgbVlaue as NSString).substring(from: 2)
        }
        if rgbVlaue.hasPrefix("#"){
            rgbVlaue = (rgbVlaue as NSString).substring(from: 1)
        }
        if rgbVlaue.lengthOfBytes(using: String.Encoding.utf8) != 6
        {
            return UIColor.white
        }
        var range = NSRange()
        range.location = 0
        range.length = 2
        var r:String = (rgbVlaue as NSString).substring(with: range)
        range.location = 2
        var g:String = (rgbVlaue as NSString).substring(with: range)
        range.location = 4
        var b:String = (rgbVlaue as NSString).substring(with: range)
        
        var scannerR = Scanner(string: r)
        var colorR = UInt32()
        scannerR.scanHexInt32(&colorR)
        var scannerG = Scanner(string:g)
        var colorG = UInt32()
        scannerG.scanHexInt32(&colorG)
        var scannerB = Scanner(string: b)
        var colorB = UInt32()
        scannerB.scanHexInt32(&colorB)
        
        return UIColor(red: CGFloat(Float(colorR) / 255.0), green: CGFloat(Float(colorG) / 255.0), blue: CGFloat(Float(colorB) / 255.0), alpha:1.0)
    }
}
