//
//  EssieColor.swift
//  ColorDetection
//
//  Created by ykwon on 5/15/18.
//  Copyright © 2018 BarbarianGroup. All rights reserved.
//

import Foundation

class EssieColor: NSObject {
    let _id: String
    let productName: String
    let productCategory: String
    let productSubCategory: String
    let hexValue: String
    let shortDescription: String
    let longDescription: String
    let finish: String
    let productCollection: String
    let productImage: String
    let productSwatch: String
    let collectionCategory: String
    
    init(_id: String, productName: String, productCategory: String, productSubCategory: String, hexValue: String, shortDescription: String, longDescription: String, finish: String, productCollection: String, productImage: String, productSwatch: String, collectionCategory: String) {
        self._id = _id
        self.productName = productName
        self.productCategory = productCategory
        self.productSubCategory = productSubCategory
        self.hexValue = hexValue
        self.shortDescription = shortDescription
        self.longDescription = longDescription
        self.finish = finish
        self.productCollection = productCollection
        self.productImage = productImage
        self.productSwatch = productSwatch
        self.collectionCategory = collectionCategory
        
        super.init()
    }
    
    init?(json: AnyObject) {
        self._id = json["_id"] as! String
        self.productName = json["productName"] as! String
        self.productCategory = json["productCategory"] as! String
        self.productSubCategory = json["productSubCategory"] as! String
        self.hexValue = json["hexValue"] as! String
        self.shortDescription = json["shortDescription"] as! String
        self.longDescription = json["longDescription"] as! String
        self.finish = json["finish"] as! String
        self.productCollection = json["productCollection"] as! String
        self.productImage = json["productImage"] as! String
        self.productSwatch = json["productSwatch"] as! String
        self.collectionCategory = json["collectionCategory"] as! String
    }

}


